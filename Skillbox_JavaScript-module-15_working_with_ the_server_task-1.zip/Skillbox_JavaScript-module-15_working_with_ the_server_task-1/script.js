// Функция обработки отправки формы
function handleFormSubmit(e) {
  e.preventDefault();

  const title = document.getElementById("title").value;
  const genre = document.getElementById("genre").value;
  const releaseYear = document.getElementById("releaseYear").value;

  // Валидация
  if (!title || !genre || !releaseYear) {
    alert("Пожалуйста, заполните все поля.");
    return;
  }

  const isWatched = document.getElementById("isWatched").checked;

  const film = {
    title: title,
    genre: genre,
    releaseYear: releaseYear,
    isWatched: isWatched,
  };

  addFilm(film);
}

// Функция добавления фильма
async function addFilm(film) {
  await fetch("https://sb-film.skillbox.cc/films", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      email: "ovikdevil@gmail.com",
    },
    body: JSON.stringify(film),
  });
  renderTable(); // Обновление таблицы
}

// Функция рендеринга таблицы с фильтрами
async function renderTable(filters = {}) {
  const filmsResponse = await fetch("https://sb-film.skillbox.cc/films", {
    headers: {
      email: "ovikdevil@gmail.com",
    },
  });
  const films = await filmsResponse.json();

  // Применение фильтров
  const filteredFilms = films.filter(film => {
    return (
      (filters.title ? film.title.includes(filters.title) : true) &&
      (filters.genre ? film.genre.includes(filters.genre) : true) &&
      (filters.releaseYear ? film.releaseYear.includes(filters.releaseYear) : true) &&
      (filters.isWatched === undefined || filters.isWatched === 'all' ? true : (filters.isWatched === 'yes' ? film.isWatched : !film.isWatched))
    );
  });

  const filmTableBody = document.getElementById("film-tbody");
  filmTableBody.innerHTML = "";

  // Добавление строк в таблицу
  filteredFilms.forEach((film, index) => {
    const row = document.createElement("tr");
    row.innerHTML = `
      <td>${film.title}</td>
      <td>${film.genre}</td>
      <td>${film.releaseYear}</td>
      <td>${film.isWatched ? "Да" : "Нет"}</td>
      <td><button onclick="deleteFilm(${film.id})">Удалить</button></td>
    `;
    filmTableBody.appendChild(row);
  });
}

// Функция удаления фильма
async function deleteFilm(id) {
  await fetch(`https://sb-film.skillbox.cc/films/${id}`, {
    method: "DELETE",
    headers: {
      email: "ovikdevil@gmail.com",
    },
  });
  renderTable(); // Обновление таблицы
}

// Функция удаления всех фильмов
async function deleteAllFilms() {
  await fetch("https://sb-film.skillbox.cc/films", {
    method: "DELETE",
    headers: {
      email: "ovikdevil@gmail.com",
    },
  });
  renderTable(); // Обновление таблицы
}

// Обработчик фильтров
document.getElementById("filter-title").addEventListener("input", function() {
  renderTable({
    title: this.value,
    genre: document.getElementById("filter-genre").value,
    releaseYear: document.getElementById("filter-year").value,
    isWatched: document.getElementById("filter-watched").value,
  });
});

document.getElementById("filter-genre").addEventListener("input", function() {
  renderTable({
    title: document.getElementById("filter-title").value,
    genre: this.value,
    releaseYear: document.getElementById("filter-year").value,
    isWatched: document.getElementById("filter-watched").value,
  });
});

document.getElementById("filter-year").addEventListener("input", function() {
  renderTable({
    title: document.getElementById("filter-title").value,
    genre: document.getElementById("filter-genre").value,
    releaseYear: this.value,
    isWatched: document.getElementById("filter-watched").value,
  });
});

document.getElementById("filter-watched").addEventListener("change", function() {
  renderTable({
    title: document.getElementById("filter-title").value,
    genre: document.getElementById("filter-genre").value,
    releaseYear: document.getElementById("filter-year").value,
    isWatched: this.value,
  });
});

// Добавляем обработчик отправки формы
document
  .getElementById("film-form")
  .addEventListener("submit", handleFormSubmit);

// Отображение фильмов при загрузке страницы
renderTable();
